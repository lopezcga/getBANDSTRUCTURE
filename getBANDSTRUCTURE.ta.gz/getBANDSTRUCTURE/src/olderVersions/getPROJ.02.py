#!/usr/bin/env python

# -------------------------------------------------------------------------------------
# TITLE: getPROJ
# AUTHOR: G. Lopez-Candales
# AFFILIATION: University at Buffalo, SUNY, Peihong Zhang's Electronic Structure Group
# DATE: 02-23-2018
# LAST MODIFIED: 02-25-2018
# VERSION: 0.02
# -------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------
# DESCRIPTION: Script to pull out the band structure with projection of atomic 
#              characters. Storing the data as {k: rk, Enk, s, py, pz, px, d ...}.
#              THIS ONLY WORKS FOR PROCAR, an outputted VASP file
# USAGE: ./getPROJ.py > data.dat
# UPDATE: Version 0.02
#  Description: Include code which takes into account ion type, writing to date files
#               for each ion type, and scaling the k-path. All now taken from vasprun
#               instead
#  Usage: ./getPROJ.py
# -------------------------------------------------------------------------------------

# Imports
import os, subprocess

# Identifiers:
vasprun = 'vasprun.xml'
PROCAR = 'PROCAR'
nKPOINTS = 0
nBANDS = 0
nIONS = 0
IONS = {}
KPOINTS = {}
s = py = pz = px = dxy = dyz = dz2 = dxz = dx2 = 0

# Get the number of kpoints 
command = """sed -e '1,/kpointlist/d' vasprun.xml | sed -e '/varray>/,$d' | wc -l > nKPOINTS.tmp"""
os.system(command)
with open('nKPOINTS.tmp') as tmpFile:
  lines = tmpFile.readlines()
  lines = [line.strip() for line in lines]
for line in lines:
  checkLine = line.split()
  nKPOINTS = int(checkLine[0])
tmpFile.close()

# Get the number of bands
command = """grep '"NBANDS"' vasprun.xml > NBANDS.tmp"""
os.system(command)
with open('NBANDS.tmp') as tmpFile:
  lines = tmpFile.readlines()
  lines = [line.strip() for line in lines]
for line in lines:
  checkLine = line.strip('</i>')
  checkLine = checkLine.split()
  nBANDS = int(checkLine[-1])
tmpFile.close()

# Get number of ions, number of different types of ions, and how many ions are of each type
command = """sed -e '1,/atominfo/d' vasprun.xml | sed -e '/atominfo/,$d' > IONS.tmp"""
os.system(command)
with open('IONS.tmp') as tmpFile:
  lines = tmpFile.readlines()
  lines = [line.strip() for line in lines]
typeCounter = 0
totalCount = 0
for line in lines:
  checkLine = line.split()
  if checkLine[0] == '<rc><c>':
    nION_ionType = checkLine[1].rstrip('</c><c>')
    nION_ionType = nION_ionType.replace('</c><c>', ' ')
    nION_ionType = nION_ionType.split()
    #IONS[typeCounter] = [nION_ionType[1], [i for i in range(int(nION_ionType[0]))]]
    IONS[typeCounter] = [nION_ionType[1], [i for i in range(totalCount, totalCount + int(nION_ionType[0]))]]
    typeCounter += 1
    totalCount = int(nION_ionType[0])
tmpFile.close()

#print IONS

# Take only needed information (band structure) and store it in tmp file
#command = """sed -e '1,/<dimension dim="3">ion</d' vasprun.xml | sed -e '/<projected>/,$d' > BANDS.tmp"""
command = """sed -e '1,/projected>/d' vasprun.xml | sed -e '/projected>/,$d' > BANDS.tmp"""
os.system(command) 
# Get the line number to split the BAND.tmp file into 2 parts, the top is the kpoints and the bands for each
# the second is the ion atomic orbital contributions
command = """grep -n '</eigenvalues>' BANDS.tmp"""
line4Split = subprocess.check_output(command, shell=True)
line4Split = line4Split.strip(':   </eigenvalues>\n')
#print "Split at line: " + str(line4Split)
command = "sed -e '" + str(line4Split) + ",$d' BANDS.tmp > KandB.tmp"
os.system(command)
tmpFile = 'KandB.tmp'
#os.system(command)
with open(tmpFile) as inFile:
  lines = inFile.readlines()
  lines = [line.strip() for line in lines]
for line in lines:
  checkLine = line.split()
  if len(checkLine) > 1 and checkLine[1] == 'comment="kpoint':
    ik = checkLine[2].strip('">')
    KPOINTS[ik] = []
  # For eac hk-point get the nBANDS associated with it
  if checkLine[0] == '<r>':
    Enk = checkLine[1]
    KPOINTS[ik].append({Enk : [s, py, pz, px, dxy, dyz, dz2, dxz, dx2]})                     #  <----- Gives me k-point and Enk only

# Append the IONS dict such that they contain the kpoints and bands
for ionType in IONS:
  IONS[ionType].append(KPOINTS)

# Now get the second half which has the atomic characteristics
command = "sed -e '1," + str(line4Split) + "d' BANDS.tmp > atomic.tmp"
os.system(command)
tmpFile = 'atomic.tmp'
#print KPOINTS['2']
with open(tmpFile) as inFile:
  lines = inFile.readlines()
  lines = [line.strip() for line in lines]
for line in lines:
  checkLine = line.split()
  if len(checkLine) > 1 and checkLine[1] == 'comment="kpoint':
    ik = checkLine[2].strip('">')
    bandCounter = 0
  if len(checkLine) > 1 and checkLine[1] == 'comment="band':
    typeCounter = 0 # Keep track of the ion being worked on
    ionCounter = 0
    bandCounter += 1
  # For each k-pont and band get the atomic characteristics for each type of ion
  if checkLine[0] == '<r>':
    for ionType in IONS:
      if ionCounter == 4 or ionCounter == 0:  # NEEDS TO BE GENERALIZED
        s = py = pz = px = dxy = dyz = dz2 = dxz = dx2 = 0
      if ionCounter in IONS[ionType][1]:
        s += float(checkLine[1])
        #print s, ik, ionType, IONS[ionType][0], ionCounter, py, checkLine[2] #WORKS for sulfur, Fe keeps up the adding BREAKS AT BAND 18 for Fe
        py += float(checkLine[2])
        #print s, ik, ionType, IONS[ionType][0], ionCounter, py, checkLine[2] #WORKS for sulfur, Fe keeps up the adding BREAKS AT BAND 18 for Fe
        pz += float(checkLine[3])
        px += float(checkLine[4])
        dxy += float(checkLine[5])
        dyz += float(checkLine[6])
        dz2 += float(checkLine[7])
        dxz += float(checkLine[8])
        dx2 += float(checkLine[9])
        Enk = KPOINTS[ik][bandCounter-1].keys()
        Enk = Enk[0]
        IONS[ionType][2][ik][bandCounter-1][Enk][0] = s
        IONS[ionType][2][ik][bandCounter-1][Enk][1] = py
        IONS[ionType][2][ik][bandCounter-1][Enk][2] = pz
        IONS[ionType][2][ik][bandCounter-1][Enk][3] = px
        IONS[ionType][2][ik][bandCounter-1][Enk][4] = dxy
        IONS[ionType][2][ik][bandCounter-1][Enk][5] = dyz
        IONS[ionType][2][ik][bandCounter-1][Enk][6] = dz2
        IONS[ionType][2][ik][bandCounter-1][Enk][7] = dxz
        IONS[ionType][2][ik][bandCounter-1][Enk][8] = dx2
        #print Enk, ik, bandCounter-1, ionCounter, IONS[ionType][0]
    ionCounter += 1

#print IONS[0][2]['600'][71]['16.9563'][0], IONS[0][0]

# Append the IONS dict such that they contain the kpoints and bands
for ionType in IONS:
  IONS[ionType].append(KPOINTS)

# Save the band structure to a file
outFile = open('band_structure.dat', 'w')
for ik in KPOINTS:
  for band in range(nBANDS):
    Enk = KPOINTS[ik][band].keys()
    Enk = Enk[0]
    outFile.write(str(int(ik) / float(len(KPOINTS))) + '\t' + str(Enk) + '\n')
outFile.close()

# Save the band structure projections from the separate ions
for ionType in IONS:
  fileName = IONS[ionType][0] + '_band_structure.dat'
  outFile = open(fileName, 'w')
  for ik in KPOINTS:
     for band in range(nBANDS):
       Enk = IONS[ionType][2][ik][band].keys()
       Enk = Enk[0]
       s = str(IONS[ionType][2][ik][band][Enk][0])
       print s, IONS[ionType][0], ik  # PRINTS SAME OUTPUT NO MATTER THE ION TYPE!!
       py = str(IONS[ionType][2][ik][band][Enk][1])
       pz = str(IONS[ionType][2][ik][band][Enk][2])
       px = str(IONS[ionType][2][ik][band][Enk][3])
       dxy = str(IONS[ionType][2][ik][band][Enk][4])
       dyz = str(IONS[ionType][2][ik][band][Enk][5])
       dz2 = str(IONS[ionType][2][ik][band][Enk][6])
       dxz = str(IONS[ionType][2][ik][band][Enk][7])
       dx2 = str(IONS[ionType][2][ik][band][Enk][8])
       outFile.write(str(int(ik) / float(len(KPOINTS))) + '\t' + str(Enk) + s + '\t' + py + '\t' + pz + '\t' + px + '\t' + dxy + '\t' + dyz + '\t' + dz2 + '\t' + dxz + '\t' + dx2 + '\n')
  outFile.close()

# Clean
command = """rm *.tmp"""
#os.system(command)

