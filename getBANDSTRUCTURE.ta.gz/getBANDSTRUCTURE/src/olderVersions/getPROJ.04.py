#!/usr/bin/env python

# -------------------------------------------------------------------------------------
# TITLE: getPROJ
# AUTHOR: G. Lopez-Candales
# AFFILIATION: University at Buffalo, SUNY, Peihong Zhang's Electronic Structure Group
# DATE: 02-23-2018
# LAST MODIFIED: 02-26-2018
# VERSION: 0.04
# -------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------
# DESCRIPTION: Script to pull out the band structure with projection of atomic 
#              characters. Storing the data as {k: rk, Enk, s, py, pz, px, d ...}.
#              THIS ONLY WORKS FOR PROCAR, an outputted VASP file
# USAGE: ./getPROJ.py > data.dat
# UPDATE: Version 0.02
#  Description: Include code which takes into account ion type, writing to date files
#               for each ion type, and scaling the k-path. All now taken from vasprun
#               instead
#  Usage: ./getPROJ.py
# UPDATE: Version 0.03
#  Description: Changed where the writing to files occurs and seems to work ok
#               but need a way to check for definite proof.
#  Usage: ./getPROJ.03.py
# UPDATE: Version 0.04
#  Description: Write messy parts of the code and generalize certain parts so it works
#               for other systems. May move back to using PROCAR, however if done
#               will need more input files since that file doesn't hold all the info
#               needed. This way the need for importing subprocess won't be needed.
#  Usage: ./getPROJ.04.py
# -------------------------------------------------------------------------------------

# Imports
import os, time

# Identifiers:
vasprun = 'vasprun.xml'
PROCAR = 'PROCAR'
POSCAR = 'POSCAR'
nKPOINTS = 0
nBANDS = 0
nIONS = 0
IONS = {}
BANDS = {}
s = py = pz = px = dxy = dyz = dz2 = dxz = dx2 = 0.0e0
KPOINTS = {}
timeLog = 'timeLog.dat'

# Open a file to log the amount of time for each step
timeFile = open(timeLog, 'w')

# Start timing the entire run
initial = time.time() 

# Get the number of kpoints , bands, and number of ions
start = time.time()
with open(PROCAR) as tmpFile:
  lines = tmpFile.readlines()
  lines = [line.strip() for line in lines]
secondLine = lines[1].split()
nKPOINTS = int(secondLine[3])
nBANDS = int(secondLine[7])
nIONS = int(secondLine[11])
tmpFile.close()
end = time.time()
elapsedTime = (end - start)
timeFile.write("Time elapsed for # of k-points, bands, and ions grabbing: " + str(elapsedTime)  + " s " + '\n')

# Determine how many ion types and how many of each ion type there are:
start = time.time()
command = """sed -e '1,/atominfo/d' vasprun.xml | sed -e '/atominfo/,$d' > IONS.tmp"""
os.system(command)
with open('IONS.tmp') as tmpFile:
  lines = tmpFile.readlines()
  lines = [line.strip() for line in lines]
typeCounter = 0
totalCount = 0
for line in lines:
  checkLine = line.split()
  if checkLine[0] == '<rc><c>':
    nION_ionType = checkLine[1].rstrip('</c><c>')
    nION_ionType = nION_ionType.replace('</c><c>', ' ')
    nION_ionType = nION_ionType.split()
    IONS[typeCounter] = [nION_ionType[1], [i+1 for i in range(totalCount, totalCount + int(nION_ionType[0]))]]
    typeCounter += 1
    totalCount = int(nION_ionType[0])
tmpFile.close()
end = time.time()
elapsedTime = end - start
timeFile.write("Time elapsed for ion type and ion counting: " + str(elapsedTime)  + " s " + '\n')

# Read through PROCAR storing for each band: k-point, Enk, s, py, pz, px, dxy, dyz, dz2, dxz, dx2
start = time.time()
with open(PROCAR) as tmpFile:
  lines = tmpFile.readlines()
  lines = [line.strip() for line in lines]
kpointCounter = 0
for line in lines:
  checkLine = line.split()
  # Look for lines which specify which band it is and the energy of Enk
  if len(checkLine) > 0 and checkLine[0] == 'band':
    bandNumber = checkLine[1]
    # Get the energy associated with this band and k-point (Enk)
    Enk = checkLine[4]
  # Loop through the possible ion types to separate atomic contributions (only do this for lines with integers in front)
  if len(checkLine) > 0 and (checkLine[0] != 'k-point' and checkLine[0] != 'band' and checkLine[0] != 'ion' and checkLine[0] != 'tot' and checkLine[0] != '#' and checkLine[0] != 'PROCAR'):
    for ionType in IONS:
      # Keep track of the number of ions you have gone through
      ionCounter = int(checkLine[0])
      if (ionCounter in IONS[ionType][1]):
        # Store the kpoint, Enk, s, p, d for this band
        s += float(checkLine[1])
        py += float(checkLine[2]) 
        pz += float(checkLine[3])
        px += float(checkLine[4])
        dxy += float(checkLine[5])
        dyz += float(checkLine[6])
        dz2 += float(checkLine[7])
        dxz += float(checkLine[8])
        dx2 += float(checkLine[9])
        # If starting with a new ion type start s, p, d = 0, and store the current kpoint, Enk, s, p, d for ths band
        if ionCounter == IONS[ionType][1][-1]:
           IONS[ionType].append({str(Enk): [kpointCounter / float(nKPOINTS), s, py, pz, px, dxy, dyz, dz2, dxz, dx2]})
           s = py = pz = px = dxy = dyz = dz2 = dxz = dx2 = 0.0e0    
    # When through all nBANDS for a given k-point increase the k-point number
    if (bandNumber == str(nBANDS)) and ionCounter == 12:
      kpointCounter += 1
tmpFile.close()
end = time.time()
elapsedTime = end - start
timeFile.write("Time elapsed for grabbing Enk, s, p, d, etc: " + str(elapsedTime) + " s " + '\n')

# Display results
start = time.time()
for ionType in IONS:
  fileName = IONS[ionType][0] + '_projected_band_structure.dat'
  with open(fileName, 'w') as outputFile:
    for j in range(2,nKPOINTS * nBANDS):
      for band in IONS[ionType][j]:
        Enk = str(band)
        k = str(IONS[ionType][j][band][0])
        s = str(IONS[ionType][j][band][1])
        py = str(IONS[ionType][j][band][2])
        pz = str(IONS[ionType][j][band][3])
        px = str(IONS[ionType][j][band][4])
        dxy = str(IONS[ionType][j][band][5])
        dyz = str(IONS[ionType][j][band][6])
        dz2 = str(IONS[ionType][j][band][7])
        dxz = str(IONS[ionType][j][band][8])
        dx2 = str(IONS[ionType][j][band][9])
        outputFile.write(k + '\t' + Enk + '\t' + s + '\t' + py + '\t' + pz + '\t' + px + '\t' + dxy + '\t' + dyz + '\t' + dz2 + '\t' + dxz + '\t' + dx2 + '\n')
  outputFile.close()
end = time.time()
elapsedTime = end - start
timeFile.write("Time elapsed for writing the projected band structures: " + str(elapsedTime) + " s " + '\n')

# End timing the run
final = time.time()
elapsedTime = final - initial
timeFile.write("Total time elapsed: " + str(elapsedTime) + " s " + '\n')
