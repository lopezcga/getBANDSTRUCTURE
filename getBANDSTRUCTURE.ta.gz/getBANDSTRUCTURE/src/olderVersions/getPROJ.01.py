#!/usr/bin/env python

# -------------------------------------------------------------------------------------
# TITLE: getPROJ
# AUTHOR: G. Lopez-Candales
# AFFILIATION: University at Buffalo, SUNY, Peihong Zhang's Electronic Structure Group
# DATE: 02-23-2018
# LAST MODIFIED: 02-25-2018
# VERSION: 0.02
# -------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------
# DESCRIPTION: Script to pull out the band structure with projection of atomic 
#              characters. Storing the data as {k: rk, Enk, s, py, pz, px, d ...}.
#              THIS ONLY WORKS FOR PROCAR, an outputted VASP file
# USAGE: ./getPROJ.py > data.dat
# UPDATE: Version 0.02
#  Description: Include code which takes into account ion type, writing to date files
#               for each ion type, and scaling the k-path
#  Usage: ./getPROJ.py
# -------------------------------------------------------------------------------------

# Imports
import os

# Identifiers:
PROCAR = 'PROCAR'
INCAR = 'INCAR'
nKPOINTS = 0
nBANDS = 0
nIONS = 0
KPOINTS = {}
s = py = pz = px = dxy = dyz = dz2 = dxz = dx2 = tot = 0

# Read in PROCAR line by line into a list
with open(PROCAR) as inFile:
  lines = inFile.readlines()
  #lines = [line.rstrip('\n') for line in lines]
  lines = [line.strip() for line in lines]

# Get the number of k-points, number of bands, and number of ions
secondLine = lines[1].split()
nKPOINTS = int(secondLine[3])
nBANDS = int(secondLine[7])
nIONS = int(secondLine[11])
IONS = [str(ion) for ion in range(1,nIONS+1)]
#print nKPOINTS, nBANDS, nIONS

# Go through the file line by line
for line in lines:
  # Look for lines that aren't empty
  if line.strip():
    lineCheck = line.split()
    # Look for bands
    if lineCheck[0] == 'k-point':
      #print lineCheck[3], lineCheck[4], lineCheck[5].strip('weight')
      #print lineCheck[-1]
      # For each k-point first get the label, the reciprocal space coordinate, and its weight
      kpoint = lineCheck[0] + ' ' +  lineCheck[1]
      rkpoint = [lineCheck[3], lineCheck[4], lineCheck[5].strip('weight')]
      weight = float(lineCheck[-1])
      KPOINTS[kpoint] = [rkpoint]
    if lineCheck[0] == 'band':
      # Now for this kpoint get each band's energy and the contribution of s, p, etc.
      #print lineCheck
      Enk = float(lineCheck[4])
      KPOINTS[kpoint].append(Enk)
    ionTypeCounter = 0
    if lineCheck[0] in IONS:
      # FOr each ion in the system get the s, p, d, etc contribution
      #print lineCheck
      s += float(lineCheck[1])
      py += float(lineCheck[2])
      pz += float(lineCheck[3])
      px += float(lineCheck[4])
      dxy += float(lineCheck[5])
      dyz += float(lineCheck[6])
      dz2 += float(lineCheck[7])
      dxz += float(lineCheck[8])
      dx2 += float(lineCheck[8])
      #tot += float(lineCheck[9])
    # If gone through each ion append to kpoints
    if lineCheck[0] == str(IONS[-1]):
      #print kpoint
      KPOINTS[kpoint].append(s)
      KPOINTS[kpoint].append(py)
      KPOINTS[kpoint].append(pz)
      KPOINTS[kpoint].append(px)
      KPOINTS[kpoint].append(dxy)
      KPOINTS[kpoint].append(dyz)
      KPOINTS[kpoint].append(dz2)
      KPOINTS[kpoint].append(dxz)
      KPOINTS[kpoint].append(dx2)
      #KPOINTS[kpoint].append(tot)
      # Restart the s, px, py, etc
      s = py = pz = px = dxy = dyz = dz2 = dxz = dx2 = tot = 0

#print KPOINTS["k-point 1"]
print "# k-point Enk s py pz px dxy    dyz    dz2    dxz    dx2 "
# Store the output to a file for plotting
for ik in range(len(KPOINTS)):
  bandCounter = 0
  # For each k-point there are nBANDS each with their own projections on s, px, py, pz, ect.
  for ib in range(1, len(KPOINTS['k-point ' + str(ik + 1)]) + 1, 10):
    if bandCounter < nBANDS:
      print ik/float(len(KPOINTS)), KPOINTS['k-point ' + str(ik + 1)][ib], KPOINTS['k-point ' + str(ik + 1)][ib + 1], KPOINTS['k-point ' + str(ik + 1)][ib + 2], KPOINTS['k-point ' + str(ik + 1)][ib + 3], KPOINTS['k-point ' + str(ik + 1)][ib + 4], KPOINTS['k-point ' + str(ik + 1)][ib + 5], KPOINTS['k-point ' + str(ik + 1)][ib + 6], KPOINTS['k-point ' + str(ik + 1)][ib + 7], KPOINTS['k-point ' + str(ik + 1)][ib + 8], KPOINTS['k-point ' + str(ik + 1)][ib + 9] #, KPOINTS['k-point ' + str(ik + 1)][ib + 10]
    #pass
    bandCounter += 1

#print "It seems I am only plotting one band, so all k-points but only the first band from each k-point..."
