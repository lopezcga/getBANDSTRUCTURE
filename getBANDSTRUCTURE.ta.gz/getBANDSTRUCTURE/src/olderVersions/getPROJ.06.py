#!/usr/bin/env python

# -------------------------------------------------------------------------------------
# TITLE: getPROJ
# AUTHOR: G. Lopez-Candales
# AFFILIATION: University at Buffalo, SUNY, Peihong Zhang's Electronic Structure Group
# DATE: 02-23-2018
# LAST MODIFIED: 03-14-2018
# VERSION: 0.06
# -------------------------------------------------------------------------------------

# -------------------------------------------------------------------------------------
# DESCRIPTION: Script to pull out the band structure with projection of atomic 
#              characters. Storing the data as {k: rk, Enk, s, py, pz, px, d ...}.
#              THIS ONLY WORKS FOR PROCAR, an outputted VASP file
# USAGE: ./getPROJ.py > data.dat
# UPDATE: Version 0.02 (02-23-2018)
#  Description: Include code which takes into account ion type, writing to date files
#               for each ion type, and scaling the k-path. All now taken from vasprun
#               instead
#  Usage: ./getPROJ.py
# UPDATE: Version 0.03
#  Description: Changed where the writing to files occurs and seems to work ok
#               but need a way to check for definite proof.
#  Usage: ./getPROJ.03.py
# UPDATE: Version 0.04
#  Description: Write messy parts of the code and generalize certain parts so it works
#               for other systems. May move back to using PROCAR, however if done
#               will need more input files since that file doesn't hold all the info
#               needed. This way the need for importing subprocess won't be needed.
#  Usage: ./getPROJ.04.py
# UPDATE: Version 0.04.mod
#  Description: Adding in more comments for a course assignment, will not be kept in 
#               user version. Extra comments added are with ## not #
#  Usage: ./getPROJ.04.mod.py
# UPDATE: Version 0.05 (02-27-2018)
#  Description: Reduce clutter by introducing a function for opening a file of interest
#               and turning it into a list of words. Also introduced a new function
#               which checks to see if the required input files are in the current 
#               working directory.
#  Usage: ./getPROJ.05.py
# UPDATE: Version 0.06 (03-14-2018)
#  Description: Add the ability to take into account spin polarized calculations. The
#               PROCAR file can be cut into two halves, the top half corresponds to
#               the spin 1 component (up) and the bottom half is the spin down 
#		component. Write a function which checks if a spin polarized 
#		calculation was performed (check how many times the first comment in 
#		the PROCAR file is seen within the file, if once then spin unpolarized
#		, else then it is spin-polarized). Then add an outer loop to main 
#		part of the program to do everything twice if the job is spin 
#		polarized, this meaans file names must be appended if spin polarized
# -------------------------------------------------------------------------------------

# Imports
import os, glob, time
from math import ceil


# Identifiersi used are:
vasprun = 'vasprun.xml'  #  Input file 
PROCAR = 'PROCAR'   	 #  Input file
nKPOINTS = 0		 #  Number of k-points
nBANDS = 0		 #  Number of bands
nIONS = 0		 #  Number of ions
IONS = {} 		 #  Dict of ions to hold their respective projections
s = py = pz = px = dxy = dyz = dz2 = dxz = dx2 = 0.0e0
timeLog = 'timeLog.dat'  #  Output log


# -------------------------------------------------------------------------------------
#                   			FUNCTIONS				      #
# -------------------------------------------------------------------------------------


def File2List(inputFile):
  # DESCRIPTION: a function which takes the name of an input file as a string or variable
  #              which holds a string, then reads it line by line stroring it as a list
  #              with the newline characters ('\n') removed so the list holds only the
  #              words of the file. If nothing goes wrong the function returns this list.
  try:
    with open(inputFile) as tmpFile:
      ## Read in the lines from the input file
      lines = tmpFile.readlines()
      ## Remove the newline character (\n) from each line of the file
      lines = [line.strip() for line in lines]
      tmpFile.close()
      return lines
  except IOError:
    print("ERROR: " + inputFile + " cannot be open or read...")
    # Check if the file exists in the current working directory
    command = "ls " + inputFile
    directoryFiles = glob.glob(command)
    if inputFile not in directoryFiles:
      print("... " + inputFile + " is not in the current working directory!")
    else:
      print("... " + inputFile + " is in the current working directory but still cannot be read or opened correctly!")
    # Exit the program
    exit()
    # Return an empty list since nothing was able to be read in
    return []

def checkFiles2Start(fileList):
  # DESCRIPTION: a function to be called at the begining of the main program to 
  #              check the the files required to start are actually in the
  #              current working directory
  # Check that the required input files are in the current working directory
  for neededFile in fileList:
    command = neededFile
    ## Get a list of the current items in the working directory
    directoryFiles = glob.glob(command)
    ## Trun the directoryFiles from a string into a list
    if neededFile not in directoryFiles:
      print("ERROR: " + neededFile + " not in the current working directory...")
      exit()
  # If no problems are seen continue run of the program
  return

def check4SpinPolarized():
  # DESCRIPTION: a function which grabs the 2nd line in the PROCAR file and sees if
  #              it appears once or twice, return False if once, True if twice.
  #              If True then split the make a copy of the PROCAR file and 
  #              split the copy in half
  # Grab the second line of the PROCAR file and store it
  inputFile = 'PROCAR'
  lines = File2List(inputFile)
  secondLine = lines[1]
  readFile = open(inputFile).read()
  count = readFile.count(secondLine)
  if count == 1:
    check = False
  else:
    check = True
    # Cut the file in half 
    where2cut = int(ceil(len(lines) / 2.0))
    command = "split -l " + str(where2cut) + ' ' + inputFile
    os.system(command)
    # Rename the two files xaa and xab to PROCAR_up and PROCAR_down
    command = "mv xaa PROCAR_up"
    os.system(command)
    command = "mv xab PROCAR_down"
    os.system(command)
  return check

# -------------------------------------------------------------------------------------
#                                    END OF FUNCTIONS                                 #
# -------------------------------------------------------------------------------------


# Before starting make sure that the required input files are available for use:
requiredFiles = [vasprun, PROCAR]
checkFiles2Start(requiredFiles)


# Open a file to log the amount of time for each step
timeFile = open(timeLog, 'w')


# Start timing the entire run
initial = time.time() 


# Get the number of kpoints , bands, and number of ions
start = time.time()
# Call the File2List function to get the number of kpoints , bands, and number of ions from PROCAR
lines = File2List(PROCAR)
# Hold onto the second line of PROCAR which holds nKPOINTS, nBANDS, and nIONS
secondLine = lines[1].split()
## The number of k-points used is the 4th element on the second line of PROCAR
nKPOINTS = int(secondLine[3])
## The number of k-points used is the 8th element on the second line of PROCAR
nBANDS = int(secondLine[7])
## The number of k-points used is the 12th element on the second line of PROCAR
nIONS = int(secondLine[11])
end = time.time()
elapsedTime = (end - start)
## Print the elapsed time to the time log
timeFile.write("Time elapsed for # of k-points, bands, and ions grabbing: " + str(elapsedTime)  + " s " + '\n')


# Determine how many ion types and how many of each ion type there are:
start = time.time()
## Store the command needed to get a portion of the input file so that the whole file doesn't need to be read through
command = """sed -e '1,/atominfo/d' vasprun.xml | sed -e '/atominfo/,$d' > IONS.tmp"""
os.system(command)
lines = File2List('IONS.tmp')
## typeCounter is used to keep track of the type of ion we are focused on
typeCounter = 0
## totalCount is used to keep track of the total number of ions since each type might occur more than once
totalCount = 0
## Read through the file line by line 
for line in lines:
  ## Split the line (a long string) into a list of words for checking
  checkLine = line.split()
  ## Looking for a particular line which holds how many of each ion type there are
  if checkLine[0] == '<rc><c>':
    ## Remove extras that we don't need
    nION_ionType = checkLine[1].rstrip('</c><c>')
    ## Replace what is left over with a space so the number of each ion and ion symbol can be extracted
    nION_ionType = nION_ionType.replace('</c><c>', ' ')
    ## Split the segment now into a list with the first element being the number of this ion type and second the symbol
    nION_ionType = nION_ionType.split()
    ## Fill the dictionary IONS with a list holding the ion symbol and a list of the number corresponding to each ion
    ## For example in FeS2 there are 4 Fe atoms and 8 S atoms, I need Fe to be associated with a list [1,2,3,4] and S with [5,6,7,8,9,10,11,12] which will be needed later
    IONS[typeCounter] = [nION_ionType[1], [i+1 for i in range(totalCount, totalCount + int(nION_ionType[0]))]]
    ## Increase the type counter since I am giving each type a number (potential bug: does this work for Fe S Fe or just Fe S, i.e. repeated types not listed together)
    typeCounter += 1
    totalCount = int(nION_ionType[0])
end = time.time()
elapsedTime = end - start
timeFile.write("Time elapsed for ion type and ion counting: " + str(elapsedTime)  + " s " + '\n')


# Check if the run was spin polarized or not
spinPolarized = check4SpinPolarized()
if spinPolarized == False:
  # Only need one input file (PROCAR)
  inputFiles = ['PROCAR']
else:
  # Need two input files (PROCAR_up and PROCAR_down)
  inputFiles = ['PROCAR_up', 'PROCAR_down']


# Read through PROCAR file(s) storing for each band: k-point, Enk, s, py, pz, px, dxy, dyz, dz2, dxz, dx2
start = time.time()
for inputFile in inputFiles:
  for ion in IONS:
    IONS[ion] = IONS[ion][0:2]
  lines = File2List(inputFile)
  ## Keep track of the k-point we are currently on
  kpointCounter = 0
  for line in lines:
    checkLine = line.split()
    # Look for lines which specify which band it is and the energy of Enk
    if len(checkLine) > 0 and checkLine[0] == 'band':
      ## Each band is given a number in the input file use it to keep track of which one we are one (needed for counting which k-point we are on)
      bandNumber = checkLine[1]
      # Get the energy associated with this band and k-point (Enk)
      Enk = checkLine[4]
    # Loop through the possible ion types to separate atomic contributions (only do this for lines with integers in front)
    ## Look for lines which correspond to ion contributions only, exclude the kpoint, band, ion, tot, comment, and title line
    if len(checkLine) > 0 and (checkLine[0] != 'k-point' and checkLine[0] != 'band' and checkLine[0] != 'ion' and checkLine[0] != 'tot' and checkLine[0] != '#' and checkLine[0] != 'PROCAR'):
      ## Loop through the different ion types so their band projections can be grabbed
      for ionType in IONS:
        # Keep track of the number of ions you have gone through
        ionCounter = int(checkLine[0])
        ## If the ion belongs to ionType sum the contribtutions and put it in the correct key in the IONS dictionary
        if (ionCounter in IONS[ionType][1]):
          # Store the kpoint, Enk, s, p, d for this band (Order matters for the orbital characteristics check PROCAR)
          s += float(checkLine[1])
          py += float(checkLine[2]) 
          pz += float(checkLine[3])
          px += float(checkLine[4])
          dxy += float(checkLine[5])
          dyz += float(checkLine[6])
          dz2 += float(checkLine[7])
          dxz += float(checkLine[8])
          dx2 += float(checkLine[9])
          # If starting with a new ion type start s, p, d = 0, and store the current kpoint, Enk, s, p, d for ths band
          if ionCounter == IONS[ionType][1][-1]:
             ## At the end of each ionType fill the dictionary according to which type you are currently on
             IONS[ionType].append({str(Enk): [kpointCounter / float(nKPOINTS), s, py, pz, px, dxy, dyz, dz2, dxz, dx2]})
             s = py = pz = px = dxy = dyz = dz2 = dxz = dx2 = 0.0e0    
      # When through all nBANDS for a given k-point increase the k-point number
      if (bandNumber == str(nBANDS)) and ionCounter == nIONS:
        kpointCounter += 1
  end = time.time()
  elapsedTime = end - start
  timeFile.write("Time elapsed for grabbing Enk, s, p, d, etc from " + inputFile + ": " + str(elapsedTime) + " s " + '\n')
 
  
  # Display results
  start = time.time()
  ## For each ion type create a file for the projected band structure
  for ionType in IONS:
    ## Name the file according to the ion symbol, if spin polarized ad up or down to the name
    if spinPolarized == False:
      fileName = IONS[ionType][0] + '_projected_band_structure.dat'
    elif spinPolarized == True:
      if inputFile == 'PROCAR_up':
        fileName = IONS[ionType][0] + '_projected_band_structure_up.dat'
      elif inputFile == 'PROCAR_down':
        fileName = IONS[ionType][0] + '_projected_band_structure_down.dat'
    with open(fileName, 'w') as outputFile:
      ## Add a comment line so that the user knowns which column is for what
      outputFile.write("# k " + '\t' + 'Enk' + '\t' + 's' + '\t' + 'py' + '\t' + 'pz' + '\t' + 'px' + '\t' + 'dxy' + '\t' + 'dyz' + '\t' + 'dz2' + '\t' + 'dxz' + '\t' + 'dx2' + '\n')
      ## Loop through each band with the associated k-point in the IONS dictionary
      for j in range(2,nKPOINTS * nBANDS):
        ## Loop through the keys in IONS which are eigenvalues (Enk, i.e. the bands)
        for band in IONS[ionType][j]:
          ## Convert to strings if they are not already so this step doesn't need to be done in the writing
          Enk = str(band)
          k = str(IONS[ionType][j][band][0])
          s = str(IONS[ionType][j][band][1])
          py = str(IONS[ionType][j][band][2])
          pz = str(IONS[ionType][j][band][3])
          px = str(IONS[ionType][j][band][4])
          dxy = str(IONS[ionType][j][band][5])
          dyz = str(IONS[ionType][j][band][6])
          dz2 = str(IONS[ionType][j][band][7])
          dxz = str(IONS[ionType][j][band][8])
          dx2 = str(IONS[ionType][j][band][9])
          ## Write each line to the file
          outputFile.write(k + '\t' + Enk + '\t' + s + '\t' + py + '\t' + pz + '\t' + px + '\t' + dxy + '\t' + dyz + '\t' + dz2 + '\t' + dxz + '\t' + dx2 + '\n')
    outputFile.close()
  # if spin polarized set s p and d to floats again
  if spinPolarized == True:
    s = py = pz = px = dxy = dyz = dz2 = dxz = dx2 = 0.0e0
end = time.time()
elapsedTime = end - start
# Tell the time log if the calculation was spin polarized or not
if spinPolarized == False:
  timeFile.write("Time elapsed for writing the projected band structures: " + str(elapsedTime) + " s " + '\n')
elif spinPolarized == True:
  timeFile.write("Time elapsed for writing the spin resolved projected band structures: " + str(elapsedTime) + " s " + '\n')


# End timing the run
final = time.time()
elapsedTime = final - initial
timeFile.write("Total time elapsed: " + str(elapsedTime) + " s " + '\n')


# Clean up the mess of tmp files
if spinPolarized == True:
  command = "rm *.tmp PROCAR_up PROCAR_down"
  os.system(command)
else:
  command = "rm *.tmp"
  os.system(command)
